import { Router } from 'express';
import { z } from 'zod';
import { ok } from '../lib/http.js';
import { asyncHandler } from '../middleware/error.js';
import { optionalAuth } from '../middleware/auth.js';
import { getAiProvider } from '../services/ai.js';

const router = Router();

/** AI 同城助手推荐 (国内合规大模型) */
router.post(
  '/recommend',
  optionalAuth,
  asyncHandler(async (req, res) => {
    const { prompt } = z.object({ prompt: z.string().min(1).max(500) }).parse(req.body);
    const result = await getAiProvider().recommend(prompt);
    return ok(res, result);
  }),
);
/** AI 闲鱼风商品文案生成 */
router.post(
  '/generate-description',
  optionalAuth,
  asyncHandler(async (req, res) => {
    const { title, category } = z.object({ 
      title: z.string().optional(), 
      category: z.string().optional() 
    }).parse(req.body);
    const hint = title || category || '闲置好物';
    const prompt = `请为一款名为“${hint}”的闲置商品写一段闲鱼风格的转手文案。字数控制在100字左右，要包含转手原因、成色新、价格实在等卖点。`;
    const result = await getAiProvider().generateText(prompt);
    return ok(res, { description: result });
  }),
);

export default router;
