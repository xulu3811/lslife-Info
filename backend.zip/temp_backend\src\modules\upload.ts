import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { ok, ApiError } from '../lib/http.js';
import { asyncHandler } from '../middleware/error.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

// Configure multer storage
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, 'public/uploads');
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, `${uuidv4()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new ApiError(400, '只允许上传图片文件'));
    }
  },
});

/** 上传单张图片 */
router.post(
  '/',
  requireAuth,
  upload.single('image'),
  asyncHandler(async (req, res) => {
    if (!req.file) {
      throw new ApiError(400, '未找到上传的图片文件');
    }
    
    // 构建可通过网络访问的 URL
    const baseUrl = `${req.protocol}://${req.get('host')}`;
    const url = `${baseUrl}/uploads/${req.file.filename}`;

    return ok(res, { url });
  })
);

/** 批量上传图片 */
router.post(
  '/batch',
  requireAuth,
  upload.array('images', 9), // Max 9 images
  asyncHandler(async (req, res) => {
    if (!req.files || (req.files as Express.Multer.File[]).length === 0) {
      throw new ApiError(400, '未找到上传的图片文件');
    }

    const baseUrl = `${req.protocol}://${req.get('host')}`;
    const urls = (req.files as Express.Multer.File[]).map(file => `${baseUrl}/uploads/${file.filename}`);

    return ok(res, { urls });
  })
);

export default router;
